---
theme:
  override:
    footer:
      style: template
      left: "@myhandle"
      center: "Introduction to footer styling"
      right: "{current_slide} / {total_slides}"
---

First slide
===

The important bit in this presentation is the **footer at the bottom**.

<!-- end_slide -->

Second slide
===

_nothing to see here_
