# Columns and pauses

Columns and pauses can interact with each other in useful ways:

<!-- pause -->

<!-- column_layout: [1, 1] -->

<!-- column: 1 -->

![](../examples/doge.png)

After this pause, the text on the left will show up

<!-- pause -->

<!-- column: 0 -->

This is useful for various things:

<!-- incremental_lists: true -->
* Lorem.
* Ipsum.
* Etcetera.

